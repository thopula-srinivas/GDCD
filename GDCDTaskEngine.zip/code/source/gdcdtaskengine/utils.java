package gdcdtaskengine;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import com.webmethods.caf.faces.data.dir.IPrincipalProvider;
import com.webmethods.caf.faces.data.dir.RoleModel;
import com.webmethods.caf.faces.data.dir.UserModel;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void fetchUsersBasedOnRoles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(fetchUsersBasedOnRoles)>> ---
		// @sigtype java 3.5
		// [i] field:1:required roleList
		// [o] recref:1:required userInfo gdcdtaskengine.docs:UserInfo
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	roleList = IDataUtil.getStringArray( pipelineCursor, "roleList" );
		pipelineCursor.destroy();
		ArrayList<IData> userSet = new ArrayList<IData>();
		ArrayList<String> listUser = new ArrayList<String>();
		
		for (String tempRole : roleList){
		RoleModel roleModel = new RoleModel();
		roleModel.setPrincipalID(tempRole);
		
		List<IPrincipalProvider> list = roleModel.getMembers();
		
		
		for(IPrincipalProvider temp : list){
			IData tempData = IDataFactory.create();
			IDataCursor tempDataCursor = tempData.getCursor();
			IDataUtil.put(tempDataCursor, "displayName", temp.getDisplayName());
			IDataUtil.put(tempDataCursor, "userId", temp.getPrincipalID());
			userSet.add(tempData);
		}
		}
		IData[] finalUserList = new IData[userSet.size()];
		userSet.toArray(finalUserList);
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		String[]	userList = new String[1];
		userList[0] = "userList";
		IDataUtil.put( pipelineCursor_1, "userInfo", finalUserList );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

